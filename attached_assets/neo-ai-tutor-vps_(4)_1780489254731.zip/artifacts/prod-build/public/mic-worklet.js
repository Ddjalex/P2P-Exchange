class PCMProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    // 4096 samples ≈ 256 ms at 16 kHz — sends ~4 msgs/s instead of ~23 msgs/s.
    // Larger chunks are much more reliable on poor Ethiopian 2G/3G/4G connections
    // because each WebSocket frame has fixed TCP/TLS overhead; fewer, bigger
    // frames means less overhead and fewer retransmits under packet loss.
    this._bufferSize = 4096;
    this._buffer = new Float32Array(this._bufferSize);
    this._offset = 0;
  }

  process(inputs) {
    const input = inputs[0];
    if (!input || !input[0]) return true;

    const samples = input[0];

    for (let i = 0; i < samples.length; i++) {
      this._buffer[this._offset++] = samples[i];

      if (this._offset >= this._bufferSize) {
        // እዚህ ጋር በየ 1024 ሳምፕሉ በፍጥነት ወደ ዋናው ድህረ ገጽ (Main Thread) ይልካል
        this.port.postMessage(this._buffer);
        this._offset = 0;
      }
    }

    return true;
  }
}

registerProcessor("pcm-processor", PCMProcessor);