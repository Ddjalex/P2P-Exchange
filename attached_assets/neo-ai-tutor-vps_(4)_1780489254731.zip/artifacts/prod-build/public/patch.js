

(function(){
  const STATUS_TEXTS = new Set(["Disconnected","Connecting...","Connected","ተቋርጧል","ሲገናኝ...","ተገናኝቷል"]);
  const REPLACEMENTS = [
    [/Free Conversation/g, 'Test Conversation'],
    [/Free conversation/g, 'Test conversation'],
    [/Free/g, 'Test']
  ];
  let publicConfigCache = null;
  let adminConfigCache = null;
  let authMeCache = null;
  let modalReady = false;

  function token(){ return localStorage.getItem('vt_token') || ''; }

  // -------- Client-side guard: enforce admin's min_deposit_amount on every
  // POST /api/user/deposits, no matter which form (main app or hotfix) sends it.
  (function installDepositGuard(){
    if (typeof window === 'undefined' || !window.fetch || window.__aiHotfixDepositGuard) return;
    window.__aiHotfixDepositGuard = true;
    var origFetch = window.fetch.bind(window);
    function readNumberFromCfg(cfg){
      if (!cfg) return 0;
      // welcome_bonus_min_deposit is the key the public config endpoint
      // actually exposes; min_deposit_amount is admin-only.
      var v = cfg.welcome_bonus_min_deposit;
      if (v == null || v === '') v = cfg.min_deposit_amount;
      if (v == null || v === '') v = cfg.min_deposit_amount_text;
      var m = String(v == null ? '' : v).match(/\d+(?:\.\d+)?/);
      return m ? Number(m[0]) : 0;
    }
    // Last-resort floor if both DB lookup and admin save fail.
    var FALLBACK_MIN_DEPOSIT = 200;
    var lastKnownMin = FALLBACK_MIN_DEPOSIT;
    async function getCurrentMin(){
      try {
        var r = await origFetch('/api/public/config', { cache: 'no-store' });
        if (r.ok){
          var cfg = await r.json();
          var fromCfg = readNumberFromCfg(cfg);
          if (fromCfg > 0){ lastKnownMin = fromCfg; return fromCfg; }
        }
      } catch(e) {}
      return lastKnownMin || FALLBACK_MIN_DEPOSIT;
    }
    // Expose so the hint text can show the current live value.
    window.__aiHotfixGetMin = getCurrentMin;
    function extractAmount(body){
      try {
        if (!body) return null;
        if (typeof FormData !== 'undefined' && body instanceof FormData){
          var v = body.get('amount');
          if (v == null) return null;
          var n = Number(v);
          return isNaN(n) ? null : n;
        }
        if (typeof body === 'string'){
          // try JSON first
          try { var obj = JSON.parse(body); if (obj && obj.amount != null){ var nn = Number(obj.amount); return isNaN(nn) ? null : nn; } } catch(e){}
          // fallback: urlencoded
          var m = body.match(/(?:^|&)amount=([^&]+)/);
          if (m){ var n2 = Number(decodeURIComponent(m[1])); return isNaN(n2) ? null : n2; }
        }
        if (body && typeof body === 'object' && 'amount' in body){
          var n3 = Number(body.amount); return isNaN(n3) ? null : n3;
        }
      } catch(e){}
      return null;
    }
    window.fetch = async function(input, init){
      try {
        var url = typeof input === 'string' ? input : (input && input.url) || '';
        var method = (init && init.method) || (input && input.method) || 'GET';
        if (/\/deposit/i.test(url) && /^POST$/i.test(method)){
          var min = await getCurrentMin();
          if (min > 0){
            var amount = extractAmount(init && init.body);
            if (amount != null && amount < min){
              try { alert('Minimum deposit amount is ' + min + ' ETB. Please enter ' + min + ' or more.'); } catch(e){}
              // Return a synthetic 400 so the form sees a clean failure.
              return new Response(JSON.stringify({ error: 'Minimum deposit amount is ' + min + ' ETB.' }), {
                status: 400,
                headers: { 'Content-Type': 'application/json' }
              });
            }
          }
        }
      } catch(e) { /* never break real requests */ }
      return origFetch(input, init);
    };
  })();

  // -------- XHR guard (axios and other XHR-based clients use this path,
  // so the fetch wrapper alone is not enough to block low deposits).
  (function installXhrDepositGuard(){
    if (typeof window === 'undefined' || !window.XMLHttpRequest || window.__aiHotfixXhrGuard) return;
    window.__aiHotfixXhrGuard = true;
    var XHR = window.XMLHttpRequest;
    var origOpen = XHR.prototype.open;
    var origSend = XHR.prototype.send;
    XHR.prototype.open = function(method, url){
      try {
        this.__aiHotfixMethod = String(method || 'GET').toUpperCase();
        this.__aiHotfixUrl = String(url || '');
      } catch(e){}
      return origOpen.apply(this, arguments);
    };
    XHR.prototype.send = function(body){
      var self = this;
      var url = self.__aiHotfixUrl || '';
      var method = self.__aiHotfixMethod || 'GET';
      if (method === 'POST' && /\/deposit/i.test(url)){
        // Defer send until we know the configured minimum.
        getCurrentMin().then(function(min){
          try {
            if (min > 0){
              var amount = extractAmount(body);
              if (amount != null && amount < min){
                try { alert('Minimum deposit amount is ' + min + ' ETB. Please enter ' + min + ' or more.'); } catch(e){}
                // Synthesize a failed XHR so the caller's error handler runs.
                try {
                  Object.defineProperty(self, 'readyState', { configurable: true, get: function(){ return 4; } });
                  Object.defineProperty(self, 'status', { configurable: true, get: function(){ return 400; } });
                  Object.defineProperty(self, 'statusText', { configurable: true, get: function(){ return 'Bad Request'; } });
                  Object.defineProperty(self, 'responseText', { configurable: true, get: function(){ return JSON.stringify({ error: 'Minimum deposit amount is ' + min + ' ETB.' }); } });
                  Object.defineProperty(self, 'response', { configurable: true, get: function(){ return self.responseText; } });
                } catch(e){}
                try { self.dispatchEvent(new Event('readystatechange')); } catch(e){}
                try { self.dispatchEvent(new Event('load')); } catch(e){}
                try { self.dispatchEvent(new Event('loadend')); } catch(e){}
                if (typeof self.onreadystatechange === 'function'){ try { self.onreadystatechange(); } catch(e){} }
                if (typeof self.onload === 'function'){ try { self.onload(); } catch(e){} }
                if (typeof self.onloadend === 'function'){ try { self.onloadend(); } catch(e){} }
                return;
              }
            }
          } catch(e){}
          try { origSend.call(self, body); } catch(e){}
        }).catch(function(){ try { origSend.call(self, body); } catch(e){} });
        return;
      }
      return origSend.apply(self, arguments);
    };
  })();

  async function api(path, opts={}){
    const headers = Object.assign({}, opts.headers || {});
    if (token()) headers['Authorization'] = 'Bearer ' + token();
    return fetch(path, Object.assign({}, opts, { headers }));
  }
  async function getPublicConfig(force){
    if (publicConfigCache && !force) return publicConfigCache;
    try { const r = await fetch('/api/public/config'); publicConfigCache = await r.json(); } catch { publicConfigCache = {}; }
    return publicConfigCache || {};
  }
  async function getAdminConfig(force){
    if (adminConfigCache && !force) return adminConfigCache;
    try { const r = await api('/api/admin/config'); if (!r.ok) throw 0; adminConfigCache = await r.json(); } catch { adminConfigCache = null; }
    return adminConfigCache;
  }
  async function getMe(force){
    if (authMeCache && !force) return authMeCache;
    try { const r = await api('/api/auth/me'); if (!r.ok) throw 0; authMeCache = await r.json(); } catch { authMeCache = null; }
    return authMeCache;
  }
  function parseAmount(v, fallback){
    const m = String(v == null ? '' : v).match(/\d+(?:\.\d+)?/);
    const n = m ? Number(m[0]) : (fallback || 0);
    return Number.isFinite(n) ? n : (fallback || 0);
  }
  function textReplaceNode(node){
    if (!node || node.nodeType !== Node.TEXT_NODE) return;
    let txt = node.nodeValue;
    let next = txt;
    REPLACEMENTS.forEach(([re, rep]) => { next = next.replace(re, rep); });
    if (next !== txt) node.nodeValue = next;
  }
  function walkReplace(root){
    const walker = document.createTreeWalker(root || document.body, NodeFilter.SHOW_TEXT, null);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(textReplaceNode);
  }
  function hideStatusTexts(){
    document.querySelectorAll('span,div,p,small,strong').forEach(el => {
      const text = (el.textContent || '').trim();
      if (!STATUS_TEXTS.has(text)) return;
      const rect = el.getBoundingClientRect();
      if (rect.width > 180 || rect.height > 40) return;
      el.classList.add('ai-hotfix-hidden-status-text');
      el.setAttribute('aria-hidden','true');
    });
  }
  function bindBalanceButtons(){
    document.querySelectorAll('button,div,a,span').forEach(el => {
      if (el.dataset.aiHotfixBalanceBound === '1') return;
      const text = (el.textContent || '').replace(/\s+/g,' ').trim();
      if (!/ETB/i.test(text)) return;
      const rect = el.getBoundingClientRect();
      if (rect.width < 40 || rect.height < 18) return;
      el.dataset.aiHotfixBalanceBound = '1';
      el.classList.add('ai-hotfix-balance-chip');
      el.addEventListener('click', function(ev){
        ev.preventDefault();
        ev.stopPropagation();
        openDepositModal();
      }, true);
    });
  }
  function createModalShell(){
    if (modalReady) return;
    modalReady = true;
    const backdrop = document.createElement('div');
    backdrop.className = 'ai-hotfix-modal-backdrop';
    backdrop.id = 'ai-hotfix-deposit-backdrop';
    backdrop.innerHTML = `
      <div class="ai-hotfix-modal" role="dialog" aria-modal="true" aria-labelledby="ai-hotfix-title">
        <div class="ai-hotfix-header">
          <div>
            <div style="font-size:13px;color:#98a9cb;margin-bottom:4px;">Balance / Deposit</div>
            <div id="ai-hotfix-title" class="ai-hotfix-title">Deposit</div>
          </div>
          <button type="button" class="ai-hotfix-close" aria-label="Close">×</button>
        </div>
        <div class="ai-hotfix-body">
          <div id="ai-hotfix-min-help" class="ai-hotfix-help" style="margin-bottom:14px;"></div>
          <div id="ai-hotfix-error" class="ai-hotfix-error"></div>
          <div id="ai-hotfix-success" class="ai-hotfix-success"></div>
          <form id="ai-hotfix-deposit-form">
            <div class="ai-hotfix-field">
              <label class="ai-hotfix-label">Payment Method *</label>
              <select id="ai-hotfix-method" class="ai-hotfix-select" required><option value="">Select payment method...</option></select>
            </div>
            <div class="ai-hotfix-field">
              <label class="ai-hotfix-label">Amount (ETB) *</label>
              <input id="ai-hotfix-amount" class="ai-hotfix-input" type="number" min="0" step="0.01" placeholder="Enter amount" required />
            </div>
            <div class="ai-hotfix-field">
              <label class="ai-hotfix-label">Receipt / Screenshot</label>
              <input id="ai-hotfix-attachment" class="ai-hotfix-input" type="file" accept="image/*,.pdf" />
            </div>
            <div class="ai-hotfix-field">
              <label class="ai-hotfix-label">Transaction Reference</label>
              <textarea id="ai-hotfix-note" class="ai-hotfix-textarea" rows="3" placeholder="Optional note or transaction reference"></textarea>
            </div>
            <button id="ai-hotfix-submit" type="submit" class="ai-hotfix-btn">Submit Deposit</button>
          </form>
        </div>
      </div>`;
    document.body.appendChild(backdrop);
    backdrop.addEventListener('click', e => { if (e.target === backdrop) closeDepositModal(); });
    backdrop.querySelector('.ai-hotfix-close').addEventListener('click', closeDepositModal);
    backdrop.querySelector('#ai-hotfix-deposit-form').addEventListener('submit', submitDepositForm);
  }
  function showMsg(type, msg){
    const err = document.getElementById('ai-hotfix-error');
    const ok = document.getElementById('ai-hotfix-success');
    if (!err || !ok) return;
    err.style.display = 'none'; ok.style.display = 'none';
    if (type === 'error' && msg){ err.textContent = msg; err.style.display = 'block'; }
    if (type === 'success' && msg){ ok.textContent = msg; ok.style.display = 'block'; }
  }
  async function populateDepositModal(){
    createModalShell();
    showMsg();
    const methodsEl = document.getElementById('ai-hotfix-method');
    methodsEl.innerHTML = '<option value="">Loading payment methods...</option>';
    const cfg = await getPublicConfig();
    const minAmount = parseAmount(cfg.min_deposit_amount_text || cfg.min_deposit_amount || 0, 0);
    const help = document.getElementById('ai-hotfix-min-help');
    help.textContent = minAmount > 0 ? ('Minimum deposit: ' + minAmount.toFixed(2) + ' ETB') : 'Enter your deposit amount and submit the receipt.';
    const amountInput = document.getElementById('ai-hotfix-amount');
    if (minAmount > 0) amountInput.min = String(minAmount);
    try {
      const r = await api('/api/user/payment-methods');
      if (!r.ok) throw new Error('Failed to load payment methods');
      const methods = await r.json();
      methodsEl.innerHTML = '<option value="">Select payment method...</option>';
      methods.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m.id;
        opt.textContent = m.name + (m.accountNumber ? ' - ' + m.accountNumber : '');
        methodsEl.appendChild(opt);
      });
    } catch (e) {
      methodsEl.innerHTML = '<option value="">Unable to load payment methods</option>';
      showMsg('error', 'Unable to load payment methods right now.');
    }
  }
  async function openDepositModal(){
    await populateDepositModal();
    document.getElementById('ai-hotfix-deposit-backdrop').style.display = 'flex';
  }
  function closeDepositModal(){
    const el = document.getElementById('ai-hotfix-deposit-backdrop');
    if (el) el.style.display = 'none';
  }
  async function submitDepositForm(ev){
    ev.preventDefault();
    showMsg();
    const submitBtn = document.getElementById('ai-hotfix-submit');
    const method = document.getElementById('ai-hotfix-method').value;
    const amountVal = document.getElementById('ai-hotfix-amount').value;
    const note = document.getElementById('ai-hotfix-note').value || '';
    const attachment = document.getElementById('ai-hotfix-attachment').files[0];
    const cfg = await getPublicConfig();
    const minAmount = parseAmount(cfg.min_deposit_amount_text || cfg.min_deposit_amount || 0, 0);
    const amountNum = Number(amountVal);
    if (!method) return showMsg('error', 'Please select a payment method.');
    if (!Number.isFinite(amountNum) || amountNum <= 0) return showMsg('error', 'Please enter a valid deposit amount.');
    if (minAmount > 0 && amountNum < minAmount) return showMsg('error', 'Minimum deposit amount is ' + minAmount.toFixed(2) + ' ETB.');
    const fd = new FormData();
    fd.append('paymentMethodId', method);
    fd.append('amount', amountVal);
    if (note.trim()) fd.append('txnRef', note.trim());
    if (attachment) fd.append('attachment', attachment);
    submitBtn.disabled = true;
    submitBtn.textContent = 'Submitting...';
    try {
      const r = await api('/api/user/deposits', { method:'POST', body: fd });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.error || 'Failed to submit deposit');
      showMsg('success', 'Deposit submitted successfully.');
      ev.target.reset();
      setTimeout(closeDepositModal, 1200);
    } catch (e) {
      showMsg('error', e.message || 'Failed to submit deposit');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Submit Deposit';
    }
  }
  async function injectAdminCard(){
    // DISABLED: this hotfix card was causing duplicates and overlapping
    // layouts on the admin Config page (and leaking onto the student page).
    // The main admin UI already has its own deposit/bonus settings, so we
    // simply remove any stray copies from anywhere in the document.
    document.querySelectorAll('#ai-hotfix-admin-config, .ai-hotfix-admin-card')
      .forEach(function(n){ try { n.remove(); } catch(e){} });
    return;
    // eslint-disable-next-line no-unreachable
    /* legacy injection (kept for reference, never runs):
    const cfg = await getAdminConfig();
    const card = document.createElement('div');
    card.id = 'ai-hotfix-admin-config';
    card.className = 'ai-hotfix-admin-card';
    card.innerHTML = `
      <div class="ai-hotfix-admin-title">Wallet Bonus & Minimum Deposit</div>
      <div class="ai-hotfix-admin-sub">Control welcome bonus and minimum deposit amount from admin config.</div>
      <div class="ai-hotfix-admin-grid">
        <div>
          <label class="ai-hotfix-label">Welcome bonus amount (ETB)</label>
          <input id="ai-hotfix-welcome-bonus" class="ai-hotfix-input" type="text" placeholder="20" value="${(cfg && (cfg.welcome_bonus_amount_text || cfg.welcome_bonus_amount || '20')) || '20'}">
        </div>
        <div>
          <label class="ai-hotfix-label">Minimum deposit amount (ETB)</label>
          <input id="ai-hotfix-min-deposit" class="ai-hotfix-input" type="text" placeholder="50" value="${(cfg && (cfg.min_deposit_amount_text || cfg.min_deposit_amount || '')) || ''}">
        </div>
      </div>
      <div style="margin-top:12px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
        <label style="display:flex;align-items:center;gap:8px;font-size:13px;color:#dbe7ff;">
          <input id="ai-hotfix-bonus-enabled" type="checkbox" ${(String(cfg && cfg.welcome_bonus_enabled || 'true').trim() !== 'false') ? 'checked' : ''}>
          Enable welcome bonus
        </label>
        <button id="ai-hotfix-admin-save" type="button" class="ai-hotfix-btn" style="max-width:240px;">Save Bonus & Deposit Settings</button>
      </div>
      <div id="ai-hotfix-admin-note" class="ai-hotfix-admin-note">Saved.</div>`;
    host.appendChild(card);
    card.querySelector('#ai-hotfix-admin-save').addEventListener('click', async function(){
      const btn = this;
      const note = card.querySelector('#ai-hotfix-admin-note');
      note.style.display = 'none';
      btn.disabled = true;
      btn.textContent = 'Saving...';
      const payload = {
        welcome_bonus_enabled: card.querySelector('#ai-hotfix-bonus-enabled').checked ? 'true' : 'false',
        welcome_bonus_amount_text: card.querySelector('#ai-hotfix-welcome-bonus').value.trim() || '20',
        min_deposit_amount_text: card.querySelector('#ai-hotfix-min-deposit').value.trim() || '0'
      };
      try {
        const r = await api('/api/admin/config', { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
        const data = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(data.error || 'Failed to save config');
        adminConfigCache = null; publicConfigCache = null;
        note.textContent = 'Saved successfully.';
        note.style.display = 'block';
      } catch (e) {
        note.textContent = e.message || 'Failed to save.';
        note.style.display = 'block';
      } finally {
        btn.disabled = false;
        btn.textContent = 'Save Bonus & Deposit Settings';
      }
    });
    */
  }
  // ====== EDIT THIS LIST when you add an AI System Prompt for a language. ======
  // Two-letter codes from the tiles ("GB English", "DE German", etc.).
  // GB=English, DE=German, CN=Chinese, ES=Spanish, JP=Japanese, SA=Arabic, FR=French.
  var READY_LANGS = ['GB', 'DE'];
  // =============================================================================

  // Make every "Choose Language to Learn" tile clickable. For languages whose
  // AI system prompt is NOT yet set up in admin/DB, mark them as "Soon"
  // (greyed-out look, "Soon" badge, click shows a small popup instead of
  // starting a conversation).
  function showComingSoonToast(name){
    try {
      var t = document.getElementById('ai-hotfix-soon-toast');
      if (!t){
        t = document.createElement('div');
        t.id = 'ai-hotfix-soon-toast';
        t.className = 'ai-hotfix-soon-toast';
        document.body.appendChild(t);
      }
      t.textContent = name ? (name + ' — Coming soon') : 'Coming soon';
      t.classList.add('show');
      clearTimeout(window.__aiHotfixSoonTimer);
      window.__aiHotfixSoonTimer = setTimeout(function(){
        t.classList.remove('show');
      }, 1800);
    } catch(e){}
  }
  function enableAllLanguageTiles(){
    // Locate the section heading "Choose Language to Learn" (uppercase via CSS in app).
    var heading = null;
    var nodes = document.querySelectorAll('div,p,span,h1,h2,h3,h4,h5,h6,label,small,strong');
    for (var i=0;i<nodes.length;i++){
      var t = (nodes[i].textContent||'').trim().toLowerCase();
      if (t === 'choose language to learn'){ heading = nodes[i]; break; }
    }
    if (!heading) return;
    // Walk up to find the container that holds the tile grid (look up to 6 levels).
    var container = heading.parentElement;
    for (var k=0; k<6 && container; k++){
      var tiles = container.querySelectorAll('button, [role="button"], a');
      if (tiles && tiles.length >= 2) break;
      container = container.parentElement;
    }
    if (!container) return;
    var candidates = container.querySelectorAll('button, [role="button"], a, div');
    candidates.forEach(function(el){
      var txt = (el.textContent||'').trim();
      // Tile labels look like "GB English", "DE German", etc. — short two-line text.
      if (!txt || txt.length > 40) return;
      if (!/^[A-Z]{2}\b/.test(txt) && !/English|German|Chinese|Spanish|Japanese|Arabic|French|Italian|Portuguese|Russian|Korean|Hindi/i.test(txt)) return;
      if (el.dataset.aiHotfixLangBound === '1') return;
      el.dataset.aiHotfixLangBound = '1';
      el.classList.add('ai-hotfix-lang-enabled');
      try { el.removeAttribute('disabled'); } catch(e){}
      try { el.removeAttribute('aria-disabled'); } catch(e){}
      try { el.style.pointerEvents = 'auto'; el.style.opacity = '1'; el.style.cursor = 'pointer'; } catch(e){}

      // Determine the language code (first 2 uppercase letters of the label).
      var codeMatch = txt.match(/^([A-Z]{2})\b/);
      var code = codeMatch ? codeMatch[1] : null;
      // Fallback: derive code from name if not prefixed.
      if (!code){
        var nameMap = {english:'GB',german:'DE',chinese:'CN',spanish:'ES',japanese:'JP',arabic:'SA',french:'FR'};
        var lc = txt.toLowerCase();
        for (var nk in nameMap){ if (lc.indexOf(nk) !== -1){ code = nameMap[nk]; break; } }
      }
      if (!code) return;
      el.dataset.aiHotfixLangCode = code;
      // Friendly name for the toast.
      var friendly = (txt.replace(/^[A-Z]{2}\s*/, '') || code).split('\n')[0].trim();
      el.dataset.aiHotfixLangName = friendly;

      var isReady = READY_LANGS.indexOf(code) !== -1;
      if (isReady){
        el.classList.remove('ai-hotfix-lang-soon');
        var oldBadge = el.querySelector('.ai-hotfix-soon-badge');
        if (oldBadge) oldBadge.remove();
        return;
      }
      // Mark as Soon: greyed-out look + badge + click intercept.
      el.classList.add('ai-hotfix-lang-soon');
      try { el.style.cursor = 'pointer'; } catch(e){}
      if (!el.querySelector('.ai-hotfix-soon-badge')){
        var badge = document.createElement('span');
        badge.className = 'ai-hotfix-soon-badge';
        badge.textContent = 'Soon';
        el.appendChild(badge);
        // Make sure the tile is positioned for absolute badge placement.
        try {
          var pos = window.getComputedStyle(el).position;
          if (!pos || pos === 'static') el.style.position = 'relative';
        } catch(e){}
      }
      // Capture-phase click handler so we run before the SPA's own handler.
      if (!el.__aiHotfixSoonClickBound){
        el.__aiHotfixSoonClickBound = true;
        el.addEventListener('click', function(ev){
          if (READY_LANGS.indexOf(el.dataset.aiHotfixLangCode) !== -1) return; // user updated list later
          ev.preventDefault();
          ev.stopPropagation();
          if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
          showComingSoonToast(el.dataset.aiHotfixLangName);
        }, true);
      }
    });
  }

  // FIX: Make the admin "AI System Prompt" textarea text readable (black on white).
  function fixAdminPromptTextarea(){
    var heading = null;
    var nodes = document.querySelectorAll('div,p,span,h1,h2,h3,h4,h5,h6,label,small,strong');
    for (var i=0;i<nodes.length;i++){
      var t = (nodes[i].textContent||'').trim();
      if (/^AI System Prompt$/i.test(t)){ heading = nodes[i]; break; }
    }
    if (!heading) return;
    var container = heading.parentElement;
    for (var k=0; k<8 && container; k++){
      var ta = container.querySelector('textarea');
      if (ta){
        if (ta.dataset.aiHotfixPromptBound !== '1'){
          ta.dataset.aiHotfixPromptBound = '1';
          ta.classList.add('ai-hotfix-admin-prompt-ta');
          try {
            ta.style.setProperty('color', '#000', 'important');
            ta.style.setProperty('-webkit-text-fill-color', '#000', 'important');
            ta.style.setProperty('background', '#ffffff', 'important');
            ta.style.setProperty('caret-color', '#000', 'important');
          } catch(e){}
        }
        break;
      }
      container = container.parentElement;
    }
  }

  // ---------------------------------------------------------------------
  // Floating admin "Bonus & Deposit" panel (replaces the old inline card).
  // Lives in document.body so React re-renders can't duplicate or move it.
  // ---------------------------------------------------------------------
  var bonusModalReady = false;
  function isAdminRoute(){ return /(^|\/)admin(\/|$)/i.test(location.pathname || ''); }
  function ensureBonusLauncher(){
    // Legacy floating launcher — superseded by the inline "Bonus & Deposit
    // Settings" card inside the React Admin Config tab. Force-remove any
    // previously injected DOM and never re-render the button.
    var existing = document.getElementById('ai-hotfix-bonus-launcher');
    if (existing && existing.parentNode) existing.parentNode.removeChild(existing);
    var modal = document.getElementById('ai-hotfix-bonus-modal');
    if (modal && modal.parentNode) modal.parentNode.removeChild(modal);
  }
  function buildBonusModal(){
    if (bonusModalReady) return;
    bonusModalReady = true;
    var wrap = document.createElement('div');
    wrap.id = 'ai-hotfix-bonus-modal';
    wrap.innerHTML = ''
      + '<div class="ai-hotfix-bonus-card" role="dialog" aria-modal="true" aria-labelledby="ai-hotfix-bonus-title">'
      +   '<div class="ai-hotfix-bonus-head">'
      +     '<div>'
      +       '<h2 id="ai-hotfix-bonus-title" class="ai-hotfix-bonus-title">Bonus & Deposit Settings</h2>'
      +       '<p class="ai-hotfix-bonus-sub">Welcome bonus and minimum deposit (saved to admin config).</p>'
      +     '</div>'
      +     '<button type="button" class="ai-hotfix-bonus-close" aria-label="Close">×</button>'
      +   '</div>'
      +   '<div class="ai-hotfix-bonus-body">'
      +     '<div id="ai-hotfix-bonus-msg" class="ai-hotfix-bonus-msg"></div>'
      +     '<label class="ai-hotfix-bonus-toggle">'
      +       '<input id="ai-hotfix-bonus-enabled" type="checkbox" checked /> Enable welcome bonus'
      +     '</label>'
      +     '<div class="ai-hotfix-bonus-row">'
      +       '<label for="ai-hotfix-bonus-amount">Welcome bonus amount (ETB)</label>'
      +       '<input id="ai-hotfix-bonus-amount" type="number" min="0" step="0.01" placeholder="20" />'
      +       '<div id="ai-hotfix-bonus-amount-hint" class="ai-hotfix-min-hint"></div>'
      +     '</div>'
      +     '<div class="ai-hotfix-bonus-row">'
      +       '<label for="ai-hotfix-bonus-min">Minimum deposit amount (ETB)</label>'
      +       '<input id="ai-hotfix-bonus-min" type="number" min="0" step="0.01" placeholder="50" />'
      +       '<div id="ai-hotfix-bonus-min-hint" class="ai-hotfix-min-hint"></div>'
      +     '</div>'
      +     '<div class="ai-hotfix-bonus-actions">'
      +       '<button type="button" class="ai-hotfix-bonus-btn ghost" id="ai-hotfix-bonus-cancel">Cancel</button>'
      +       '<button type="button" class="ai-hotfix-bonus-btn primary" id="ai-hotfix-bonus-save">Save</button>'
      +     '</div>'
      +   '</div>'
      + '</div>';
    document.body.appendChild(wrap);
    wrap.addEventListener('click', function(e){ if (e.target === wrap) closeBonusModal(); });
    wrap.querySelector('.ai-hotfix-bonus-close').addEventListener('click', closeBonusModal);
    wrap.querySelector('#ai-hotfix-bonus-cancel').addEventListener('click', closeBonusModal);
    wrap.querySelector('#ai-hotfix-bonus-save').addEventListener('click', saveBonusSettings);
  }
  function setBonusMsg(type, text){
    var el = document.getElementById('ai-hotfix-bonus-msg');
    if (!el) return;
    el.className = 'ai-hotfix-bonus-msg' + (type ? ' ' + type : '');
    el.textContent = text || '';
  }
  async function openBonusModal(){
    buildBonusModal();
    setBonusMsg('', '');
    var modal = document.getElementById('ai-hotfix-bonus-modal');
    var enabled = document.getElementById('ai-hotfix-bonus-enabled');
    var amount = document.getElementById('ai-hotfix-bonus-amount');
    var minDep = document.getElementById('ai-hotfix-bonus-min');
    var amountHint = document.getElementById('ai-hotfix-bonus-amount-hint');
    var minHint = document.getElementById('ai-hotfix-bonus-min-hint');
    enabled.checked = true; amount.value = ''; minDep.value = '';
    if (amountHint) amountHint.textContent = 'Loading current value...';
    if (minHint) minHint.textContent = 'Loading current value...';
    modal.style.display = 'flex';
    // Read from BOTH endpoints; public config is the source of truth for
    // values students actually see. Always force a fresh fetch (no cache).
    publicConfigCache = null; adminConfigCache = null;
    var cfg = await getAdminConfig(true);
    var pub = await getPublicConfig(true);
    if (!cfg && !pub){
      setBonusMsg('error', 'Could not load current settings.');
      if (amountHint) amountHint.textContent = '';
      if (minHint) minHint.textContent = '';
      return;
    }
    var src = cfg || {};
    var enabledVal = String(((pub && pub.welcome_bonus_enabled) != null ? pub.welcome_bonus_enabled : src.welcome_bonus_enabled) || 'true').trim().toLowerCase();
    enabled.checked = enabledVal !== 'false';
    var liveBonus = (pub && (pub.welcome_bonus_amount_text || pub.welcome_bonus_amount)) ||
      src.welcome_bonus_amount_text || src.welcome_bonus_amount || '';
    var liveMin = (pub && pub.welcome_bonus_min_deposit) ||
      src.min_deposit_amount_text || src.min_deposit_amount || '';
    amount.value = String(liveBonus);
    // For min deposit, prefer the public-exposed welcome_bonus_min_deposit
    // (the only key that actually reaches students).
    minDep.value = String(liveMin);
    // Show the live (database) values in green under each input. No hardcoded
    // fallback: if the database has no value, the hint stays empty.
    if (amountHint){
      var bN = Number(liveBonus);
      amountHint.textContent = (liveBonus !== '' && Number.isFinite(bN))
        ? ('Current welcome bonus: ' + bN + ' ETB') : '';
    }
    if (minHint){
      var mN = Number(liveMin);
      minHint.textContent = (liveMin !== '' && Number.isFinite(mN))
        ? ('Current minimum deposit: ' + mN + ' ETB') : '';
    }
  }
  function closeBonusModal(){
    var modal = document.getElementById('ai-hotfix-bonus-modal');
    if (modal) modal.style.display = 'none';
  }
  async function saveBonusSettings(){
    var btn = document.getElementById('ai-hotfix-bonus-save');
    var enabled = document.getElementById('ai-hotfix-bonus-enabled');
    var amount = document.getElementById('ai-hotfix-bonus-amount');
    var minDep = document.getElementById('ai-hotfix-bonus-min');
    var amountStr = (amount.value || '').toString().trim();
    var minStr = (minDep.value || '').toString().trim();
    if (amountStr === '' || isNaN(Number(amountStr)) || Number(amountStr) < 0){
      return setBonusMsg('error', 'Enter a valid welcome bonus amount.');
    }
    if (minStr === '' || isNaN(Number(minStr)) || Number(minStr) < 0){
      return setBonusMsg('error', 'Enter a valid minimum deposit amount.');
    }
    setBonusMsg('', '');
    btn.disabled = true; var label = btn.textContent; btn.textContent = 'Saving...';
    try {
      // Save to BOTH key variants the backend may read.
      var r = await api('/api/admin/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          welcome_bonus_enabled: enabled.checked ? 'true' : 'false',
          welcome_bonus_amount: amountStr,
          welcome_bonus_amount_text: amountStr,
          min_deposit_amount: minStr,
          min_deposit_amount_text: minStr,
          // Mirror under welcome_bonus_* prefix so /api/public/config exposes
          // it to students (the regular min_deposit_* keys are admin-only).
          welcome_bonus_min_deposit: minStr
        })
      });
      var data = await r.json().catch(function(){ return {}; });
      if (!r.ok) throw new Error(data.error || 'Failed to save');
      adminConfigCache = null; publicConfigCache = null;
      // VERIFY: backend silently drops keys not on its whitelist, so we
      // re-read the public config and compare against what we sent.
      var verify = null;
      try {
        var vr = await fetch('/api/public/config', { cache: 'no-store' });
        if (vr.ok) verify = await vr.json();
      } catch(e){}
      var savedAmount = verify && (verify.welcome_bonus_amount_text || verify.welcome_bonus_amount);
      var savedMin    = verify && verify.welcome_bonus_min_deposit;
      var failed = [];
      if (String(savedAmount || '') !== amountStr) failed.push('welcome bonus amount');
      if (String(savedMin || '') !== minStr) failed.push('minimum deposit');
      if (failed.length === 0){
        setBonusMsg('success', 'Saved successfully.');
        setTimeout(closeBonusModal, 900);
      } else {
        setBonusMsg('error',
          'Backend silently dropped: ' + failed.join(', ') +
          '. Ask the agent to set ' + failed.join(' and ') + ' directly in the database.');
      }
    } catch (e) {
      setBonusMsg('error', e.message || 'Failed to save');
    } finally {
      btn.disabled = false; btn.textContent = label;
    }
  }

  function injectMinDepositHint(){
    // Disabled: the React DepositModal and the React admin Bonus & Deposit
    // card both render their own live "Minimum deposit" hints from the
    // database now. The legacy injector cached a stale value and was
    // showing "200 ETB" on the admin form long after the admin had saved
    // a different number, making it look like saves weren't persisting.
    // We also strip any stale nodes a previous version of this script
    // injected so the page reflects only the live React-rendered hints.
    document.querySelectorAll('.ai-hotfix-min-hint').forEach(function(el){
      // Keep the dedicated hints inside the legacy bonus modal (those
      // have specific IDs and were rendered by patch.js itself).
      if (el.id === 'ai-hotfix-bonus-amount-hint') return;
      if (el.id === 'ai-hotfix-bonus-min-hint') return;
      el.remove();
    });
    document.querySelectorAll('input[type="number"]').forEach(function(inp){
      if (inp.dataset.aiHotfixMinHint === '1') delete inp.dataset.aiHotfixMinHint;
    });
  }
  // -------- Inject the missing AGE field on /register.
  // The SPA bundle's register form is missing an age input, but the backend
  // still requires age (validation: "valid age between 5 and 100").
  // We add the input to the form (cloning a sibling field's structure so it
  // matches the existing styling), and inject the age value into the JSON
  // body of /api/auth/send-verification and /api/auth/verify-and-register.
  var AGE_FIELD_ID = 'ai-hotfix-age-input';
  function isVerifyCodeStep(){
    var text = ((document.body && document.body.innerText) || '').toLowerCase();
    if (text.indexOf('verify your phone') !== -1 ||
        text.indexOf('we sent a 6-digit') !== -1 ||
        text.indexOf('code expires') !== -1 ||
        text.indexOf('resend code') !== -1) return true;
    var otpBoxes = 0;
    var ins = document.querySelectorAll('input');
    for (var i = 0; i < ins.length; i++){
      if ((ins[i].getAttribute('maxlength') || '') === '1') otpBoxes++;
    }
    return otpBoxes >= 4;
  }
  function injectAgeField(){
    // Disabled: the React form now has a native age field.
    // Clean up any stale injected element from previous versions.
    var stale = document.getElementById(AGE_FIELD_ID);
    if (stale) { var r = stale.closest('div') || stale.parentElement; if (r) r.remove(); }
    return;
    // eslint-disable-next-line no-unreachable
    if (document.getElementById(AGE_FIELD_ID)) return;
    // Find a labeled field we can clone for matching look & feel.
    // Strategy: locate the input whose label/preceding text says "FULL NAME"
    // (or "Full Name") and clone its wrapper.
    var inputs = document.querySelectorAll('input');
    var template = null;
    var phoneInput = null;
    var passwordInput = null;
    inputs.forEach(function(inp){
      var around = '';
      var p = inp.parentElement;
      for (var i = 0; i < 4 && p; i++){ around += ' ' + (p.textContent || ''); p = p.parentElement; }
      if (/full\s*name/i.test(around) && !template) template = inp;
      if (/phone\s*number/i.test(around) && !phoneInput) phoneInput = inp;
      if (inp.type === 'password' && !passwordInput) passwordInput = inp;
    });
    if (!template) return; // form not rendered yet
    // Walk up from the template input to find the wrapper that encloses
    // both the label and the input (the visible "row").
    var row = template;
    for (var k = 0; k < 4 && row && row.parentElement; k++){
      var pe = row.parentElement;
      if (pe.querySelector('label, [class*="label"], [class*="Label"]') &&
          pe.querySelector('input')) { row = pe; break; }
      row = pe;
    }
    if (!row || !row.parentElement) return;
    // Clone the row, then mutate it into the AGE field.
    var clone = row.cloneNode(true);
    // Update the visible label text inside the clone.
    var labelLike = clone.querySelector('label') ||
      clone.querySelector('[class*="label" i]') ||
      clone.querySelector('div, span, p');
    if (labelLike) labelLike.textContent = 'AGE';
    // Reset the cloned input.
    var newInput = clone.querySelector('input');
    if (!newInput) return;
    newInput.id = AGE_FIELD_ID;
    newInput.name = 'age';
    newInput.type = 'number';
    newInput.min = '5';
    newInput.max = '100';
    newInput.step = '1';
    newInput.placeholder = 'Enter your age';
    newInput.value = '';
    newInput.removeAttribute('disabled');
    newInput.removeAttribute('readonly');
    // Strip any availability checkmark/icon nodes copied over from Full Name.
    clone.querySelectorAll('svg, [class*="check" i], [class*="available" i]').forEach(function(n){ n.remove(); });
    // Remove any cloned hint text like "Name is available" / "Phone number is available".
    clone.querySelectorAll('*').forEach(function(n){
      if (n.children.length === 0) {
        var t = (n.textContent || '').trim().toLowerCase();
        if (/(is available|is taken|already registered|available)$/.test(t)) n.remove();
      }
    });
    // Persist the value globally so the request interceptors can read it.
    newInput.addEventListener('input', function(){
      var v = parseInt(newInput.value, 10);
      window.__aiHotfixAge = (isFinite(v) && v >= 5 && v <= 100) ? v : null;
    });
    // Insert the AGE row right before the password row (so order is:
    // Full Name, Sex, Phone Number, AGE, Password, Confirm Password).
    var anchor = passwordInput;
    if (anchor){
      // Walk anchor up to a sibling of `row` to insert before it.
      var anchorRow = anchor;
      while (anchorRow && anchorRow.parentElement !== row.parentElement){
        anchorRow = anchorRow.parentElement;
      }
      if (anchorRow){
        row.parentElement.insertBefore(clone, anchorRow);
      } else {
        row.parentElement.appendChild(clone);
      }
    } else {
      // Fallback: append at the end of the form column.
      row.parentElement.appendChild(clone);
    }
  }

  // -------- Inject `age` into the registration request bodies.
  (function installAgeInjector(){
    if (typeof window === 'undefined' || window.__aiHotfixAgeInjector) return;
    window.__aiHotfixAgeInjector = true;
    var AGE_URLS = /\/api\/auth\/(send-verification|verify-and-register)/i;
    function currentAge(){
      var el = document.getElementById(AGE_FIELD_ID);
      var v = el ? parseInt(el.value, 10) : NaN;
      if (!isFinite(v) && window.__aiHotfixAge != null) v = window.__aiHotfixAge;
      return (isFinite(v) && v >= 5 && v <= 100) ? v : null;
    }
    function mergeAgeIntoJson(bodyStr, age){
      try {
        var obj = JSON.parse(bodyStr);
        if (obj && typeof obj === 'object' && obj.age == null) obj.age = age;
        return JSON.stringify(obj);
      } catch(e){ return bodyStr; }
    }
    // fetch wrapper
    if (window.fetch){
      var origFetch = window.fetch.bind(window);
      window.fetch = function(input, init){
        try {
          var url = typeof input === 'string' ? input : (input && input.url) || '';
          if (AGE_URLS.test(url)){
            var age = currentAge();
            if (age != null && init && typeof init.body === 'string'){
              init = Object.assign({}, init, { body: mergeAgeIntoJson(init.body, age) });
            }
          }
        } catch(e){}
        return origFetch(input, init);
      };
    }
    // XHR wrapper
    if (window.XMLHttpRequest){
      var XHR = window.XMLHttpRequest;
      var origOpen = XHR.prototype.open;
      var origSend = XHR.prototype.send;
      XHR.prototype.open = function(method, url){
        try { this.__aiHotfixAgeUrl = String(url || ''); } catch(e){}
        return origOpen.apply(this, arguments);
      };
      XHR.prototype.send = function(body){
        try {
          if (this.__aiHotfixAgeUrl && AGE_URLS.test(this.__aiHotfixAgeUrl)){
            var age = currentAge();
            if (age != null && typeof body === 'string'){
              body = mergeAgeIntoJson(body, age);
              return origSend.call(this, body);
            }
          }
        } catch(e){}
        return origSend.apply(this, arguments);
      };
    }
  })();

  // ===========================================================================
  // DIRECTIONAL LEARNING (AM <-> target language) — student picker + admin tabs
  // ===========================================================================
  var DIR_LANG_MAP = {
    GB: { code:'gb', native:'English',   flag:'\uD83C\uDDEC\uD83C\uDDE7' },
    DE: { code:'de', native:'German',    flag:'\uD83C\uDDE9\uD83C\uDDEA' },
    CN: { code:'cn', native:'Chinese',   flag:'\uD83C\uDDE8\uD83C\uDDF3' },
    ES: { code:'es', native:'Spanish',   flag:'\uD83C\uDDEA\uD83C\uDDF8' },
    JP: { code:'jp', native:'Japanese',  flag:'\uD83C\uDDEF\uD83C\uDDF5' },
    SA: { code:'sa', native:'Arabic',    flag:'\uD83C\uDDF8\uD83C\uDDE6' },
    FR: { code:'fr', native:'French',    flag:'\uD83C\uDDEB\uD83C\uDDF7' }
  };
  var LANG_NAME_MAP = { GB:'english', DE:'german', CN:'chinese', ES:'spanish', JP:'japanese', SA:'arabic', FR:'french' };
  var ETH_FLAG = '\uD83C\uDDEA\uD83C\uDDF9';

  // 1) WebSocket send interceptor — stamps the chosen direction onto start_session.
  (function(){
    if (window.__aiHotfixWsPatched) return;
    if (typeof WebSocket === 'undefined') return;
    window.__aiHotfixWsPatched = true;
    var origWsSend = WebSocket.prototype.send;
    WebSocket.prototype.send = function(data){
      try {
        if (typeof data === 'string' && data.indexOf('start_session') !== -1){
          var msg = JSON.parse(data);
          if (msg && msg.type === 'start_session'){
            if (!msg.direction && window.__chosenDirection){
              msg.direction = window.__chosenDirection;
            }
            if (msg.direction){
              data = JSON.stringify(msg);
              try { console.log('[hotfix] start_session direction =', msg.direction, 'language =', msg.language); } catch(e){}
            }
          }
        }
      } catch(e){}
      return origWsSend.call(this, data);
    };
  })();

  // 2) Direction picker modal (student side).
  function showDirectionPicker(code, friendlyName, onPick){
    try {
      var existing = document.getElementById('ai-hotfix-dir-modal');
      if (existing) existing.remove();
      var info = DIR_LANG_MAP[code] || { code: (code||'xx').toLowerCase(), native: friendlyName||code, flag:'' };
      var modal = document.createElement('div');
      modal.id = 'ai-hotfix-dir-modal';
      modal.className = 'ai-hotfix-dir-modal';
      modal.innerHTML =
        '<div class="ai-hotfix-dir-card">' +
          '<div class="ai-hotfix-dir-title">Choose your learning direction</div>' +
          '<div class="ai-hotfix-dir-sub">' + info.flag + '&nbsp;' + info.native + '</div>' +
          '<button type="button" class="ai-hotfix-dir-btn" data-dir="am_to_' + info.code + '">' +
            '<div class="ai-hotfix-dir-btn-main">' + ETH_FLAG + '&nbsp;Amharic&nbsp;\u2192&nbsp;' + info.flag + '&nbsp;' + info.native + '</div>' +
            '<div class="ai-hotfix-dir-btn-sub">I speak Amharic and want to learn ' + info.native + '</div>' +
          '</button>' +
          '<button type="button" class="ai-hotfix-dir-btn" data-dir="' + info.code + '_to_am">' +
            '<div class="ai-hotfix-dir-btn-main">' + info.flag + '&nbsp;' + info.native + '&nbsp;\u2192&nbsp;' + ETH_FLAG + '&nbsp;Amharic</div>' +
            '<div class="ai-hotfix-dir-btn-sub">I speak ' + info.native + ' and want to learn Amharic</div>' +
          '</button>' +
          '<button type="button" class="ai-hotfix-dir-cancel">Cancel</button>' +
        '</div>';
      document.body.appendChild(modal);
      modal.addEventListener('click', function(ev){ if (ev.target === modal) modal.remove(); });
      modal.querySelectorAll('.ai-hotfix-dir-btn').forEach(function(b){
        b.addEventListener('click', function(){
          var d = b.getAttribute('data-dir');
          window.__chosenDirection = d;
          modal.remove();
          if (typeof onPick === 'function') onPick(d);
        });
      });
      modal.querySelector('.ai-hotfix-dir-cancel').addEventListener('click', function(){ modal.remove(); });
    } catch(e){}
  }

  // 3) Bind a capture-phase click on every READY tile that pops the direction picker
  //    BEFORE the SPA's own click handler. After the user picks, we re-fire the click
  //    with a flag so we don't intercept ourselves the second time.
  function bindDirectionPickerToReadyTiles(){
    try {
      var tiles = document.querySelectorAll('[data-ai-hotfix-lang-code]');
      tiles.forEach(function(el){
        var code = el.dataset.aiHotfixLangCode;
        if (!code) return;
        if (READY_LANGS.indexOf(code) === -1) return; // Soon tiles handled elsewhere
        if (el.__aiHotfixDirBound) return;
        el.__aiHotfixDirBound = true;
        el.addEventListener('click', function(ev){
          if (el.__aiHotfixDirSkip){ el.__aiHotfixDirSkip = false; return; }
          ev.preventDefault();
          ev.stopPropagation();
          if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
          showDirectionPicker(code, el.dataset.aiHotfixLangName, function(){
            el.__aiHotfixDirSkip = true;
            try { el.click(); } catch(e){}
          });
        }, true);
      });
    } catch(e){}
  }

  // 4) Admin AI System Prompt — direction tabs.
  // Replaces the single-textarea editor with a two-tab editor (AM->XX / XX->AM).
  // Saves to system_prompt_<lang>_am_to_<code> and system_prompt_<lang>_<code>_to_am.
  // For backwards compatibility on English, still mirrors AM->GB into "system_prompt".
  function enhanceAdminPromptForDirections(){
    return; // Disabled: directional editor is now built into the React AdminPage.
    try {
      if (!/(^|\/)admin(\/|$)/i.test(location.pathname || '')) return;
      var heading = null;
      var nodes = document.querySelectorAll('div,p,span,h1,h2,h3,h4,h5,h6,label,small,strong');
      for (var i=0;i<nodes.length;i++){
        var t = (nodes[i].textContent||'').trim();
        if (/^AI System Prompt$/i.test(t)){ heading = nodes[i]; break; }
      }
      if (!heading) return;
      // Find the section container that holds the textarea AND any language tab buttons.
      var section = heading.parentElement;
      var ta = null;
      for (var k=0; k<8 && section; k++){
        ta = section.querySelector('textarea');
        if (ta) break;
        section = section.parentElement;
      }
      if (!section || !ta) return;
      if (section.dataset.aiHotfixDirReady === '1') return;
      section.dataset.aiHotfixDirReady = '1';

      // Build our directional editor as a sibling of the textarea wrapper.
      var wrap = document.createElement('div');
      wrap.className = 'ai-hotfix-dir-admin';
      wrap.innerHTML =
        '<div class="ai-hotfix-dir-admin-head">' +
          '<div class="ai-hotfix-dir-admin-langs" id="ai-hotfix-dir-admin-langs"></div>' +
        '</div>' +
        '<div class="ai-hotfix-dir-admin-tabs">' +
          '<button type="button" class="ai-hotfix-dir-tab is-active" data-dirtab="am2x">' + ETH_FLAG + ' Amharic \u2192 <span class="ai-hotfix-dir-tab-target">English</span></button>' +
          '<button type="button" class="ai-hotfix-dir-tab" data-dirtab="x2am"><span class="ai-hotfix-dir-tab-target">English</span> \u2192 ' + ETH_FLAG + ' Amharic</button>' +
        '</div>' +
        '<textarea class="ai-hotfix-admin-prompt-ta ai-hotfix-dir-admin-ta" id="ai-hotfix-dir-admin-ta" placeholder="Enter the AI system prompt for the selected language and direction..."></textarea>' +
        '<div class="ai-hotfix-dir-admin-row">' +
          '<button type="button" class="ai-hotfix-btn" id="ai-hotfix-dir-admin-save">Save Prompt</button>' +
          '<span class="ai-hotfix-dir-admin-key" id="ai-hotfix-dir-admin-key"></span>' +
        '</div>' +
        '<div class="ai-hotfix-dir-admin-note" id="ai-hotfix-dir-admin-note"></div>';
      // Hide original textarea (keep it in DOM so SPA save buttons don't break).
      try { ta.style.display = 'none'; } catch(e){}
      ta.parentElement.insertBefore(wrap, ta);

      // Render language buttons.
      var langsBox = wrap.querySelector('#ai-hotfix-dir-admin-langs');
      Object.keys(DIR_LANG_MAP).forEach(function(c){
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'ai-hotfix-dir-admin-lang';
        b.dataset.langcode = c;
        b.innerHTML = DIR_LANG_MAP[c].flag + ' ' + DIR_LANG_MAP[c].native;
        langsBox.appendChild(b);
      });

      // State.
      var state = { lang: 'GB', dir: 'am2x', cache: {} };
      var newTa = wrap.querySelector('#ai-hotfix-dir-admin-ta');
      var keyLabel = wrap.querySelector('#ai-hotfix-dir-admin-key');
      var note = wrap.querySelector('#ai-hotfix-dir-admin-note');

      function keyFor(langCode, dirTab){
        var lng = LANG_NAME_MAP[langCode] || langCode.toLowerCase();
        var info = DIR_LANG_MAP[langCode];
        var dcode = info ? info.code : langCode.toLowerCase();
        return dirTab === 'am2x'
          ? 'system_prompt_' + lng + '_am_to_' + dcode
          : 'system_prompt_' + lng + '_' + dcode + '_to_am';
      }
      async function loadConfig(){
        try {
          var r = await api('/api/admin/config');
          if (!r.ok) return {};
          return await r.json();
        } catch(e){ return {}; }
      }
      function refreshUI(cfg){
        // Update tab targets.
        var info = DIR_LANG_MAP[state.lang] || { native:state.lang, flag:'' };
        wrap.querySelectorAll('.ai-hotfix-dir-tab-target').forEach(function(s){ s.textContent = info.native; });
        // Active classes.
        wrap.querySelectorAll('.ai-hotfix-dir-admin-lang').forEach(function(b){
          b.classList.toggle('is-active', b.dataset.langcode === state.lang);
        });
        wrap.querySelectorAll('.ai-hotfix-dir-tab').forEach(function(b){
          b.classList.toggle('is-active', b.dataset.dirtab === state.dir);
        });
        var k = keyFor(state.lang, state.dir);
        keyLabel.textContent = k;
        // Prefer cache (latest typed-in values) over server.
        if (state.cache[k] != null){
          newTa.value = state.cache[k];
        } else {
          var v = (cfg && cfg[k] != null) ? cfg[k] : '';
          // Backwards compat: AM->GB English falls back to legacy "system_prompt" if empty.
          if (!v && state.lang === 'GB' && state.dir === 'am2x' && cfg && cfg.system_prompt){
            v = cfg.system_prompt;
          }
          // German legacy: AM->DE falls back to "system_prompt_german".
          if (!v && state.lang === 'DE' && state.dir === 'am2x' && cfg && cfg.system_prompt_german){
            v = cfg.system_prompt_german;
          }
          newTa.value = v || '';
        }
        note.textContent = '';
      }
      var serverCfg = {};
      loadConfig().then(function(cfg){ serverCfg = cfg || {}; refreshUI(serverCfg); });

      // Capture edits to cache.
      newTa.addEventListener('input', function(){
        state.cache[keyFor(state.lang, state.dir)] = newTa.value;
      });

      // Language switching.
      langsBox.addEventListener('click', function(ev){
        var b = ev.target.closest('.ai-hotfix-dir-admin-lang');
        if (!b) return;
        state.lang = b.dataset.langcode;
        refreshUI(serverCfg);
      });
      // Direction tab switching.
      wrap.querySelectorAll('.ai-hotfix-dir-tab').forEach(function(b){
        b.addEventListener('click', function(){
          state.dir = b.dataset.dirtab;
          refreshUI(serverCfg);
        });
      });
      // Save handler.
      wrap.querySelector('#ai-hotfix-dir-admin-save').addEventListener('click', async function(){
        var btn = this;
        btn.disabled = true; note.textContent = 'Saving...'; note.style.color = '';
        try {
          var k = keyFor(state.lang, state.dir);
          var payload = {};
          payload[k] = newTa.value;
          // Mirror AM->GB English to legacy "system_prompt" so existing flows still work.
          if (state.lang === 'GB' && state.dir === 'am2x') payload.system_prompt = newTa.value;
          // Mirror AM->DE German to legacy "system_prompt_german".
          if (state.lang === 'DE' && state.dir === 'am2x') payload.system_prompt_german = newTa.value;
          var r = await api('/api/admin/config', {
            method:'PUT',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify(payload)
          });
          if (!r.ok) throw new Error('Save failed: HTTP ' + r.status);
          serverCfg[k] = newTa.value;
          if (payload.system_prompt) serverCfg.system_prompt = payload.system_prompt;
          if (payload.system_prompt_german) serverCfg.system_prompt_german = payload.system_prompt_german;
          adminConfigCache = null; publicConfigCache = null;
          note.style.color = '#00c97f';
          note.textContent = 'Saved \u2713  (' + k + ')';
        } catch(e){
          note.style.color = '#ef4444';
          note.textContent = (e && e.message) ? e.message : 'Save failed';
        } finally {
          btn.disabled = false;
        }
      });
    } catch(e){ try { console.warn('[hotfix] admin dir editor failed', e); } catch(_){} }
  }

  // -------------------------------------------------------------------------
  // Lightweight admin direction switcher: integrates INTO the SPA's existing
  // AI System Prompt editor (language pills + textarea + Save Prompt button)
  // by adding a single chip row above the textarea.
  // -------------------------------------------------------------------------
  var __dirAdminState = window.__dirAdminState || (window.__dirAdminState = {
    lang: 'GB', dir: 'am2x', drafts: {}, server: null, serverLoaded: false
  });
  function _dirKeyFor(langCode, dirTab){
    var lng = LANG_NAME_MAP[langCode] || (langCode||'gb').toLowerCase();
    var info = DIR_LANG_MAP[langCode] || { code: (langCode||'gb').toLowerCase() };
    return dirTab === 'am2x'
      ? 'system_prompt_' + lng + '_am_to_' + info.code
      : 'system_prompt_' + lng + '_' + info.code + '_to_am';
  }
  function _dirSetTextarea(ta, val){
    try {
      var setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
      setter.call(ta, val == null ? '' : val);
      ta.dispatchEvent(new Event('input', { bubbles: true }));
    } catch(e){
      try { ta.value = val == null ? '' : val; } catch(_){}
    }
  }
  function _dirLoadValueFor(ta, langCode, dir){
    var k = _dirKeyFor(langCode, dir);
    var cfg = __dirAdminState.server || {};
    var v;
    if (Object.prototype.hasOwnProperty.call(__dirAdminState.drafts, k)) v = __dirAdminState.drafts[k];
    else if (cfg[k] != null && cfg[k] !== '') v = cfg[k];
    else if (dir === 'am2x' && langCode === 'GB' && cfg.system_prompt) v = cfg.system_prompt;
    else if (dir === 'am2x' && langCode === 'DE' && cfg.system_prompt_german) v = cfg.system_prompt_german;
    else v = '';
    _dirSetTextarea(ta, v);
  }
  function _dirRefreshChipUI(chipRow, langCode, dir){
    try {
      var info = DIR_LANG_MAP[langCode] || { native: langCode, flag: '' };
      chipRow.querySelectorAll('.ai-hotfix-dir-chip-name').forEach(function(s){ s.textContent = info.native; });
      chipRow.querySelectorAll('.ai-hotfix-dir-chip').forEach(function(c){
        c.classList.toggle('is-active', c.getAttribute('data-dir') === dir);
      });
      var keySpan = chipRow.querySelector('.ai-hotfix-dir-chip-key');
      if (keySpan) keySpan.textContent = _dirKeyFor(langCode, dir);
    } catch(e){}
  }
  function _dirDetectActiveLangFromPills(pills){
    // Active pill: try common React-style markers, then fall back to background brightness.
    for (var i=0;i<pills.length;i++){
      var p = pills[i];
      var cls = (p.className||'').toString();
      if (/active|selected|primary/i.test(cls) || p.getAttribute('aria-selected')==='true' || p.getAttribute('aria-pressed')==='true'){
        var m = ((p.textContent||'').trim()).match(/^([A-Z]{2})\b/);
        if (m) return m[1];
      }
    }
    // Heuristic: pill whose background is NOT the most common one is active.
    try {
      var bgs = pills.map(function(p){ return window.getComputedStyle(p).backgroundColor; });
      var counts = {}; bgs.forEach(function(b){ counts[b]=(counts[b]||0)+1; });
      var common = Object.keys(counts).sort(function(a,b){ return counts[b]-counts[a]; })[0];
      for (var j=0;j<pills.length;j++){
        if (bgs[j] !== common){
          var mm = ((pills[j].textContent||'').trim()).match(/^([A-Z]{2})\b/);
          if (mm) return mm[1];
        }
      }
    } catch(e){}
    return null;
  }
  function enhanceAdminPromptDirections(){
    return; // Disabled: directional editor is now built into the React AdminPage.
    try {
      if (!/(^|\/)admin(\/|$)/i.test(location.pathname || '')) return;
      // Find the AI System Prompt section.
      var heading = null;
      var nodes = document.querySelectorAll('div,p,span,h1,h2,h3,h4,h5,h6,label,small,strong');
      for (var i=0;i<nodes.length;i++){
        var t = (nodes[i].textContent||'').trim();
        if (/^AI System Prompt$/i.test(t)){ heading = nodes[i]; break; }
      }
      if (!heading) return;
      var section = heading.parentElement;
      var ta = null;
      for (var k=0; k<10 && section; k++){
        ta = section.querySelector('textarea');
        if (ta) break;
        section = section.parentElement;
      }
      if (!section || !ta) return;
      // Locate language pills (buttons whose label looks like "GB English").
      var allBtns = section.querySelectorAll('button, [role="button"]');
      var pills = [];
      for (var b=0; b<allBtns.length; b++){
        var txt = (allBtns[b].textContent||'').trim();
        if (/^[A-Z]{2}\s+[A-Za-z]/.test(txt) && txt.length < 24) pills.push(allBtns[b]);
      }
      // Locate the Save Prompt button.
      var saveBtn = null;
      for (var s=0; s<allBtns.length; s++){
        if (/^save\s+prompt$/i.test((allBtns[s].textContent||'').trim())){ saveBtn = allBtns[s]; break; }
      }
      // Inject (or recover) chip row right above the textarea.
      var chipRow = ta.parentElement.querySelector(':scope > .ai-hotfix-dir-chiprow');
      if (!chipRow){
        chipRow = document.createElement('div');
        chipRow.className = 'ai-hotfix-dir-chiprow';
        chipRow.innerHTML =
          '<button type="button" class="ai-hotfix-dir-chip is-active" data-dir="am2x">' + ETH_FLAG + ' Amharic \u2192 <span class="ai-hotfix-dir-chip-name">English</span></button>' +
          '<button type="button" class="ai-hotfix-dir-chip" data-dir="x2am"><span class="ai-hotfix-dir-chip-name">English</span> \u2192 ' + ETH_FLAG + ' Amharic</button>' +
          '<span class="ai-hotfix-dir-chip-key"></span>';
        ta.parentElement.insertBefore(chipRow, ta);
        // Wire chip click handlers (one-time on this row).
        chipRow.querySelectorAll('.ai-hotfix-dir-chip').forEach(function(c){
          c.addEventListener('click', function(){
            // Stash current draft for OLD direction first.
            __dirAdminState.drafts[_dirKeyFor(__dirAdminState.lang, __dirAdminState.dir)] = ta.value;
            __dirAdminState.dir = c.getAttribute('data-dir');
            _dirRefreshChipUI(chipRow, __dirAdminState.lang, __dirAdminState.dir);
            _dirLoadValueFor(ta, __dirAdminState.lang, __dirAdminState.dir);
          });
        });
      }
      // Capture textarea edits as drafts for the active (lang, dir).
      if (!ta.__aiHotfixDirInputBound){
        ta.__aiHotfixDirInputBound = true;
        ta.addEventListener('input', function(){
          __dirAdminState.drafts[_dirKeyFor(__dirAdminState.lang, __dirAdminState.dir)] = ta.value;
        });
      }
      // Bind language pill clicks (re-bind across React re-renders via per-element flag).
      pills.forEach(function(p){
        if (p.__aiHotfixDirPillBound) return;
        p.__aiHotfixDirPillBound = true;
        p.addEventListener('click', function(){
          __dirAdminState.drafts[_dirKeyFor(__dirAdminState.lang, __dirAdminState.dir)] = ta.value;
          var m = ((p.textContent||'').trim()).match(/^([A-Z]{2})\b/);
          if (!m) return;
          __dirAdminState.lang = m[1];
          __dirAdminState.dir = 'am2x';
          _dirRefreshChipUI(chipRow, __dirAdminState.lang, __dirAdminState.dir);
          // Wait for the SPA to swap its own textarea content, then override with our value.
          setTimeout(function(){ _dirLoadValueFor(ta, __dirAdminState.lang, __dirAdminState.dir); }, 80);
        });
      });
      // Intercept Save Prompt — write to the directional key (and mirror legacy keys for AM->X).
      if (saveBtn && !saveBtn.__aiHotfixDirSaveBound){
        saveBtn.__aiHotfixDirSaveBound = true;
        saveBtn.addEventListener('click', function(ev){
          ev.preventDefault(); ev.stopPropagation();
          if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
          var k = _dirKeyFor(__dirAdminState.lang, __dirAdminState.dir);
          var payload = {}; payload[k] = ta.value;
          if (__dirAdminState.dir === 'am2x' && __dirAdminState.lang === 'GB') payload.system_prompt = ta.value;
          if (__dirAdminState.dir === 'am2x' && __dirAdminState.lang === 'DE') payload.system_prompt_german = ta.value;
          var keySpan = chipRow.querySelector('.ai-hotfix-dir-chip-key');
          var prevKey = keySpan ? keySpan.textContent : '';
          if (keySpan){ keySpan.textContent = 'Saving...'; keySpan.style.color = ''; }
          api('/api/admin/config', { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) })
            .then(function(r){
              if (!r.ok) throw new Error('HTTP ' + r.status);
              if (!__dirAdminState.server) __dirAdminState.server = {};
              Object.keys(payload).forEach(function(pk){ __dirAdminState.server[pk] = payload[pk]; });
              delete __dirAdminState.drafts[k];
              adminConfigCache = null; publicConfigCache = null;
              if (keySpan){ keySpan.style.color = '#00c97f'; keySpan.textContent = 'Saved \u2713  ' + k; }
              setTimeout(function(){ if (keySpan){ keySpan.style.color = ''; keySpan.textContent = prevKey || k; } }, 1800);
            })
            .catch(function(e){
              if (keySpan){ keySpan.style.color = '#ef4444'; keySpan.textContent = 'Save failed (' + ((e&&e.message)||'') + ')'; }
            });
        }, true);
      }
      // Initial server config load + initial render.
      if (!__dirAdminState.serverLoaded){
        __dirAdminState.serverLoaded = true;
        api('/api/admin/config').then(function(r){ return r.ok ? r.json() : {}; }).then(function(cfg){
          __dirAdminState.server = cfg || {};
          // Detect initial active lang from SPA's pills.
          var detected = _dirDetectActiveLangFromPills(pills);
          if (detected) __dirAdminState.lang = detected;
          _dirRefreshChipUI(chipRow, __dirAdminState.lang, __dirAdminState.dir);
          // Only override the textarea if the SPA's value matches our cached server value
          // (so we don't clobber unsaved edits the user may have just typed).
          var k = _dirKeyFor(__dirAdminState.lang, __dirAdminState.dir);
          var serverVal = (__dirAdminState.server[k] || (__dirAdminState.lang==='GB' && __dirAdminState.server.system_prompt) || (__dirAdminState.lang==='DE' && __dirAdminState.server.system_prompt_german) || '');
          if (!ta.value || ta.value === serverVal){ _dirLoadValueFor(ta, __dirAdminState.lang, __dirAdminState.dir); }
        }).catch(function(){});
      } else {
        _dirRefreshChipUI(chipRow, __dirAdminState.lang, __dirAdminState.dir);
      }
    } catch(e){ try { console.warn('[hotfix] dir admin (chip) failed', e); } catch(_){} }
  }

  function apply(){
    walkReplace(document.body);
    hideStatusTexts();
    bindBalanceButtons();
    injectAdminCard();
    enableAllLanguageTiles();
    bindDirectionPickerToReadyTiles();
    fixAdminPromptTextarea();
    // Cleanup any leftovers from older patch.js versions, then mount the lightweight chip row.
    try { document.querySelectorAll('.ai-hotfix-dir-admin').forEach(function(n){ n.remove(); }); } catch(e){}
    enhanceAdminPromptDirections();
    ensureBonusLauncher();
    injectMinDepositHint();
    injectAgeField();
  }
  document.addEventListener('DOMContentLoaded', function(){ createModalShell(); apply(); setTimeout(apply, 1200); setTimeout(apply, 3000); });
  // Coalesce mutation-driven apply() calls into one per animation frame so that
  // React's bursty re-renders don't make us walk the entire DOM hundreds of
  // times per second (which froze the admin Config page on React 19).
  var __applyScheduled = false;
  function __scheduleApply(){
    if (__applyScheduled) return;
    __applyScheduled = true;
    var run = function(){ __applyScheduled = false; try { apply(); } catch(e){} };
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(run);
    else setTimeout(run, 16);
  }
  new MutationObserver(__scheduleApply).observe(document.documentElement, { childList:true, subtree:true, characterData:true });
})();
