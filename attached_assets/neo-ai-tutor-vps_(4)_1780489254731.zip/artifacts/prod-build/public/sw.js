const CACHE_VERSION = "v4";
const STATIC_CACHE = `laroai-static-${CACHE_VERSION}`;
const NAV_CACHE = `laroai-nav-${CACHE_VERSION}`;

const PRECACHE_ASSETS = [
  "/logo.png",
  "/manifest.webmanifest",
  "/mic-worklet.js",
  "/tutor-styles.css?v=mobile-v4",
  "/patch.css?v=v19",
  "/patch.js?v=v23",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(STATIC_CACHE)
      .then((cache) => cache.addAll(PRECACHE_ASSETS))
      .catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then(async (keys) => {
      const current = [STATIC_CACHE, NAV_CACHE];
      const oldKeys = keys.filter((k) => !current.includes(k));
      const isUpdate = oldKeys.some((k) => k.startsWith("laroai-"));
      await Promise.all(oldKeys.map((k) => caches.delete(k)));
      await self.clients.claim();
      if (isUpdate) {
        const clients = await self.clients.matchAll({ includeUncontrolled: true, type: "window" });
        clients.forEach((client) => client.postMessage({ type: "SW_UPDATED" }));
      }
    })
  );
});

self.addEventListener("push", (event) => {
  let data = {};
  try {
    if (event.data) data = event.data.json();
  } catch {
    try { data = { title: "LAROAI", body: event.data && event.data.text() }; } catch { data = {}; }
  }
  const title = data.title || "LAROAI";
  const options = {
    body: data.body || "",
    icon: data.icon || "/logo.png",
    badge: data.badge || "/logo.png",
    tag: data.tag != null ? String(data.tag) : undefined,
    data: { url: data.url || "/" },
    vibrate: [120, 60, 120],
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = (event.notification.data && event.notification.data.url) || "/";
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((list) => {
      for (const client of list) {
        if ("focus" in client) {
          client.focus();
          if ("navigate" in client && target) {
            try { client.navigate(target); } catch {}
          }
          return;
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(target);
      }
    })
  );
});

self.addEventListener("message", (event) => {
  if (event.data?.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);

  if (
    url.pathname.startsWith("/api/") ||
    url.pathname.startsWith("/src/") ||
    url.pathname.startsWith("/@") ||
    url.pathname.includes("__vite") ||
    url.pathname.includes("hot-update")
  ) return;

  const isStatic =
    url.pathname.startsWith("/assets/") ||
    url.pathname.startsWith("/tutor-styles") ||
    url.pathname.startsWith("/patch") ||
    url.pathname.startsWith("/mic-worklet") ||
    url.pathname.startsWith("/logo") ||
    url.pathname.startsWith("/opengraph") ||
    url.pathname.endsWith(".css") ||
    url.pathname.endsWith(".js") ||
    url.pathname.endsWith(".png") ||
    url.pathname.endsWith(".jpg") ||
    url.pathname.endsWith(".webmanifest") ||
    url.hostname.includes("fonts.googleapis.com") ||
    url.hostname.includes("fonts.gstatic.com") ||
    url.hostname.includes("flagcdn.com");

  if (isStatic) {
    event.respondWith(
      caches.open(STATIC_CACHE).then(async (cache) => {
        const cached = await cache.match(req);
        const fetchPromise = fetch(req)
          .then((res) => {
            if (res.ok) cache.put(req, res.clone()).catch(() => {});
            return res;
          })
          .catch(() => cached);
        return cached || fetchPromise;
      })
    );
    return;
  }

  event.respondWith(
    caches.open(NAV_CACHE).then(async (cache) => {
      const cached = await cache.match(req);
      const fetchPromise = fetch(req)
        .then((res) => {
          if (res.ok) cache.put(req, res.clone()).catch(() => {});
          return res;
        })
        .catch(() => cached || caches.match("/"));
      return cached || fetchPromise;
    })
  );
});
