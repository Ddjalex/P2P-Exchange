#!/usr/bin/env bash
# ── LAROAI VPS install / start script ─────────────────────────────────────────
# Run once after uploading the zip to your VPS:
#   unzip neo-ai-tutor-vps.zip -d /var/www/laroai
#   cd /var/www/laroai
#   bash install.sh
#
# Requirements: Node >= 20, npm, pm2 (installed globally or via npm)

set -euo pipefail

echo "=== LAROAI VPS installer ==="

# 1. Ensure .env exists
if [ ! -f .env ]; then
  cp .env.example .env
  echo "[!] Created .env from .env.example — EDIT IT NOW before continuing."
  echo "    nano .env"
  exit 1
fi

# 2. Create logs directory
mkdir -p logs

# 3. Ensure PM2 is installed
if ! command -v pm2 &>/dev/null; then
  echo "[+] Installing PM2 globally..."
  npm install -g pm2
fi

# 4. Start / reload the app
if pm2 describe laroai &>/dev/null; then
  echo "[+] Reloading existing PM2 process..."
  pm2 reload ecosystem.config.cjs --update-env
else
  echo "[+] Starting LAROAI with PM2..."
  pm2 start ecosystem.config.cjs
fi

# 5. Save PM2 process list and enable startup
pm2 save
pm2 startup || true

echo ""
echo "=== Done! ==="
echo "App is running. Test with: curl http://localhost:3000/api/health"
echo "Set up Nginx using the included nginx.conf, then configure TLS with certbot."
